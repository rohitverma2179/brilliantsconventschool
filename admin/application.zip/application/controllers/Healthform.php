<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Healthform extends MY_Controller {
     public function __construct(){
		parent::__construct();
		$this->load->model('home_model');
		islogin();
	
	}
	public function index()
	{
       
       
        $this->load->view('template/header');
		$this->load->view('dashboard');
		$this->load->view('template/footer');
	}
	
	public function policy()
	{
       
        $data['data'] = $this->home_model->select();  
        $this->load->view('template/header');
		$this->load->view('policy', $data);
		$this->load->view('template/footer');
	}
	
	public function view()
	{
       
        $data['data'] = $this->home_model->view();  
        $this->load->view('template/header');
		$this->load->view('view-details', $data);
		$this->load->view('template/footer');
	}
	
	
	public function viewmember()
	{
       
        $data['data'] = $this->home_model->viewmember();  
        $this->load->view('template/header');
		$this->load->view('view-member', $data);
		$this->load->view('template/footer');
	}
	
	public function viewinner()
	{
	    
        $data['data'] = $this->home_model->viewinner();  
        $this->load->view('template/header');
		$this->load->view('view-inner', $data);
		$this->load->view('template/footer');
	}
	
	
	
	public function logout()
	{
	    $this->session->sess_destroy();
        redirect('user/login');
	}
	

	
}
